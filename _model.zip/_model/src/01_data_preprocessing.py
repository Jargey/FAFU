import pandas as pd
import numpy as np
import joblib
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
import os

# 创建文件夹（若不存在）
os.makedirs("../data/processed", exist_ok=True)

# 1. 加载原始数据
data = pd.read_csv("../data/raw/production_data.csv")
print("原始数据形状：", data.shape)
print("数据前5行：\n", data.head())

# 2. 数据清洗：处理缺失值（用中位数填充，适合生产数据）
data = data.fillna(data.median())

# 3. 处理异常值（基于IQR法，适配茶树菇生长的合理范围）
def remove_outliers(df, column):
    q1 = df[column].quantile(0.25)
    q3 = df[column].quantile(0.75)
    iqr = q3 - q1
    lower = q1 - 1.5 * iqr
    upper = q3 + 1.5 * iqr
    # 额外约束茶树菇关键参数范围（物理意义修正）
    if column == "温度":
        lower = max(lower, 20)  # 低于20℃生长停滞
        upper = min(upper, 30)  # 高于30℃易污染
    elif column == "湿度":
        lower = max(lower, 80)  # 低于80%湿度不足
        upper = min(upper, 98)  # 高于98%易霉变
    return df[(df[column] >= lower) & (df[column] <= upper)]

# 对所有列处理异常值
for col in data.columns:
    data = remove_outliers(data, col)
print("清洗后数据形状：", data.shape)

# 4. 特征工程：添加茶树菇特有的交互特征（如温度×湿度对菌丝生长的协同影响）
X = data.iloc[:, :-2].copy()  # 环境因子特征
# 添加关键交互项（基于茶树菇生物学特性）
X["温湿度交互"] = X["温度"] * X["湿度"]  # 温湿度协同作用
X["CO2与通风交互"] = X["CO2浓度"] / (X["通风量"] + 1)  # 通风对CO2的稀释作用
X = X.values  # 转为数组

# 目标变量（产量和转化率）
y = data.iloc[:, -2:].values

# 5. 特征缩放（统一尺度）
scaler_X = MinMaxScaler()
X_scaled = scaler_X.fit_transform(X)
scaler_y = MinMaxScaler()
y_scaled = scaler_y.fit_transform(y)

# 6. 划分数据集（训练集70%，验证集15%，测试集15%）
X_train, X_temp, y_train, y_temp = train_test_split(
    X_scaled, y_scaled, test_size=0.3, random_state=42
)
X_val, X_test, y_val, y_test = train_test_split(
    X_temp, y_temp, test_size=0.5, random_state=42
)

# 7. 保存预处理结果
np.save("../data/processed/X_train.npy", X_train)
np.save("../data/processed/X_val.npy", X_val)
np.save("../data/processed/X_test.npy", X_test)
np.save("../data/processed/y_train.npy", y_train)
np.save("../data/processed/y_val.npy", y_val)
np.save("../data/processed/y_test.npy", y_test)
joblib.dump(scaler_X, "../models/scaler_X.pkl")
joblib.dump(scaler_y, "../models/scaler_y.pkl")

print("数据预处理完成，结果保存在data/processed/")