import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf
import joblib
import shap
import os

# 创建结果文件夹
os.makedirs("../results", exist_ok=True)

# 1. 加载模型和数据
model = tf.keras.models.load_model("../models/production_model")
scaler_X = joblib.load("../models/scaler_X.pkl")
scaler_y = joblib.load("../models/scaler_y.pkl")
X_test = np.load("../data/processed/X_test.npy")
y_test = np.load("../data/processed/y_test.npy")
history = np.load("../results/history.npy", allow_pickle=True).item()

# 2. 测试集评估
test_loss, test_rmse, test_r2 = model.evaluate(X_test, y_test)
print(f"测试集性能：")
print(f"均方误差（MSE）：{test_loss:.4f}")
print(f"根均方误差（RMSE）：{test_rmse:.4f}")
print(f"决定系数（R²）：{test_r2:.4f}（越接近1越好）")

# 3. 可视化训练过程
# 损失曲线
plt.figure(figsize=(10, 4))
plt.plot(history['loss'], label='训练损失（MSE）')
plt.plot(history['val_loss'], label='验证损失（MSE）')
plt.xlabel('迭代次数')
plt.ylabel('MSE')
plt.title('茶树菇模型训练损失曲线')
plt.legend()
plt.savefig("../results/loss_plot.png")
plt.close()

# R²曲线
plt.figure(figsize=(10, 4))
plt.plot(history['r2'], label='训练R²')
plt.plot(history['val_r2'], label='验证R²')
plt.xlabel('迭代次数')
plt.ylabel('R²')
plt.title('茶树菇模型R²曲线')
plt.legend()
plt.savefig("../results/r2_plot.png")
plt.close()

# 4. 预测值与真实值对比（反缩放为实际单位）
y_pred_scaled = model.predict(X_test)
y_pred = scaler_y.inverse_transform(y_pred_scaled)  # 反缩放预测值
y_test_original = scaler_y.inverse_transform(y_test)  # 反缩放真实值

# 鲜重产量对比
plt.figure(figsize=(8, 6))
plt.scatter(y_test_original[:, 0], y_pred[:, 0], alpha=0.6, label='预测值')
plt.plot([y_test_original[:,0].min(), y_test_original[:,0].max()],
         [y_test_original[:,0].min(), y_test_original[:,0].max()], 'r--', label='理想线')
plt.xlabel('真实鲜重产量（kg/㎡）')
plt.ylabel('预测鲜重产量（kg/㎡）')
plt.title('茶树菇鲜重产量预测 vs 真实值')
plt.legend()
plt.savefig("../results/prediction_scatter.png")
plt.close()

# 5. 特征重要性分析（SHAP值，解释模型决策）
explainer = shap.KernelExplainer(model.predict, X_test[:50])  # 用测试集样本作为背景
shap_values = explainer.shap_values(X_test[:50])
# 特征名称（与data_preprocessing.py中的特征对应）
feature_names = ["温度", "湿度", "CO2浓度", "光照强度", "培养时间", "通风量", "温湿度交互", "CO2与通风交互"]
shap.summary_plot(shap_values, X_test[:50], feature_names=feature_names, show=False)
plt.savefig("../results/shap_summary.png")
plt.close()
print("模型评估完成，结果保存在results/")