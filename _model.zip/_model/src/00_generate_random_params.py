import numpy as np
import pandas as pd
import os

# 创建数据目录（若不存在）
os.makedirs("../data/raw", exist_ok=True)

# 茶树菇生长适宜参数范围（基于生物学特性）
param_ranges = {
    "温度": (22, 28),  # ℃，最适24-26℃
    "湿度": (85, 95),  # %，子实体生长需高湿度
    "CO2浓度": (500, 1500),  # ppm，过高抑制生长
    "光照强度": (50, 100),  # lux，弱光即可，促进原基形成
    "培养时间": (6, 10),  # 天，菌丝成熟至采收的时间
    "通风量": (100, 180)  # m³/h，保证氧气供应
}

# 生成1000组随机参数（符合均匀分布，贴近实际生产波动）
np.random.seed(42)  # 固定随机种子，确保结果可复现
n_samples = 1000
params = {}

for param, (min_val, max_val) in param_ranges.items():
    if param in ["培养时间"]:
        # 培养时间为整数
        params[param] = np.random.randint(min_val, max_val + 1, size=n_samples)
    else:
        # 其他参数为浮点数，保留1位小数
        params[param] = np.round(np.random.uniform(min_val, max_val, size=n_samples), 1)

# 基于参数生成模拟产量和转化率（加入合理关联，非随机）
# 产量与温湿度正相关，与CO2浓度负相关
params["鲜重产量"] = np.round(
    0.1 * params["温度"] + 
    0.02 * params["湿度"] + 
    0.001 * params["通风量"] - 
    0.0005 * params["CO2浓度"] + 
    0.1 * params["培养时间"] + 
    np.random.normal(0, 0.1, size=n_samples), 2
)
# 确保产量为正值
params["鲜重产量"] = np.maximum(params["鲜重产量"], 0.5)

# 生物转化率与温度、培养时间正相关
params["生物转化率"] = np.round(
    1.5 * params["温度"] + 
    0.3 * params["湿度"] / 10 + 
    2 * params["培养时间"] - 
    0.01 * params["CO2浓度"] / 10 + 
    np.random.normal(0, 1, size=n_samples), 1
)
# 确保转化率在合理范围（60%-90%）
params["生物转化率"] = np.clip(params["生物转化率"], 60, 90)

# 转换为DataFrame并保存
df = pd.DataFrame(params)
df.to_csv("../data/raw/production_data.csv", index=False)

print(f"已生成1000组茶树菇生产参数，保存至：../data/raw/production_data.csv")
print("数据前5行预览：")
print(df.head())