import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout
from keras.layers import Dense
from tensorflow.keras.regularizers import L2
import os

# 创建模型保存文件夹
os.makedirs("../models", exist_ok=True)

# 1. 加载预处理数据
X_train = np.load("../data/processed/X_train.npy")
X_val = np.load("../data/processed/X_val.npy")
y_train = np.load("../data/processed/y_train.npy")
y_val = np.load("../data/processed/y_val.npy")

# 2. 模型设计（适配茶树菇数据量，避免过拟合）
input_dim = X_train.shape[1]  # 特征数（含交互项）
model = Sequential([
    # 隐藏层：根据茶树菇特征数设计，用ReLU激活
    Dense(32, activation='relu', input_dim=input_dim, kernel_regularizer=L2(0.001)),
    Dropout(0.2),  # 防止过拟合
    Dense(16, activation='relu', kernel_regularizer=L2(0.001)),
    Dropout(0.2),
    # 输出层：2个目标（产量、转化率），线性激活
    Dense(2, activation='linear')
])

# 3. 编译模型
model.compile(
    optimizer=tf.keras.optimizers.Adam(learning_rate=0.001),
    loss='mse',
    metrics=[tf.keras.metrics.RootMeanSquaredError(name='rmse'),
             tf.keras.metrics.R2Score(name='r2')]
)

# 4. 训练回调（早停+学习率衰减）
early_stopping = tf.keras.callbacks.EarlyStopping(
    monitor='val_loss', patience=8, restore_best_weights=True
)
lr_scheduler = tf.keras.callbacks.ReduceLROnPlateau(
    monitor='val_loss', factor=0.5, patience=3, min_lr=1e-6
)

# 5. 训练模型
history = model.fit(
    X_train, y_train,
    epochs=100,
    batch_size=16,  # 茶树菇生产批次通常不大，用小批次
    validation_data=(X_val, y_val),
    callbacks=[early_stopping, lr_scheduler]
)

# 6. 保存模型和训练历史
model.save("../models/production_model")
np.save("../results/history.npy", history.history)  # 保存训练历史用于可视化
print("模型训练完成，保存在models/production_model/")