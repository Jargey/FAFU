import numpy as np
import tensorflow as tf
import joblib

# 1. 加载模型和缩放器
model = tf.keras.models.load_model("../models/production_model")
scaler_X = joblib.load("../models/scaler_X.pkl")
scaler_y = joblib.load("../models/scaler_y.pkl")

# 2. 输入新的环境因子（根据实际生产条件修改）
# 格式：[温度, 湿度, CO2浓度, 光照强度, 培养时间, 通风量]
new_env = np.array([[25.5, 90.0, 1000, 60, 8, 125]])  # 示例：25.5℃，90%湿度，CO2 1000ppm...

# 3. 添加交互项（与预处理步骤一致）
new_env_with_interact = np.hstack([
    new_env,
    (new_env[:,0] * new_env[:,1]).reshape(-1,1),  # 温湿度交互
    (new_env[:,2] / (new_env[:,5] + 1)).reshape(-1,1)  # CO2与通风交互
])

# 4. 特征缩放
new_env_scaled = scaler_X.transform(new_env_with_interact)

# 5. 预测并反缩放结果
pred_scaled = model.predict(new_env_scaled)
pred = scaler_y.inverse_transform(pred_scaled)

# 6. 输出预测结果
print("茶树菇生产预测结果：")
print(f"鲜重产量：{pred[0,0]:.2f} kg/㎡")
print(f"生物转化率：{pred[0,1]:.2f} %")