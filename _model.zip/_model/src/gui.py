import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import tensorflow as tf
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
import joblib
import os
import shap

plt.rcParams["font.family"] = ["SimHei", "WenQuanYi Micro Hei", "Heiti TC"]
plt.rcParams["axes.unicode_minus"] = False

class MushroomModelGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("茶树菇生产模型交互系统")
        self.root.geometry("1000x700")

        self.raw_data = None
        self.cleaned_data = None
        self.model = None
        self.scaler_X = None
        self.scaler_y = None
        self.X_train, self.X_val, self.X_test = None, None, None
        self.y_train, self.y_val, self.y_test = None, None, None

        self.tab_control = ttk.Notebook(root)

        # 1. 导入数据标签页
        self.tab_import = ttk.Frame(self.tab_control)
        self.tab_control.add(self.tab_import, text="1. 导入数据")
        self.init_import_tab()

        # 2. 数据清理标签页
        self.tab_clean = ttk.Frame(self.tab_control)
        self.tab_control.add(self.tab_clean, text="2. 数据清理")
        self.init_clean_tab()

        # 3. 模型训练标签页
        self.tab_train = ttk.Frame(self.tab_control)
        self.tab_control.add(self.tab_train, text="3. 模型训练")
        self.init_train_tab()

        # 4. 模型评估标签页
        self.tab_evaluate = ttk.Frame(self.tab_control)
        self.tab_control.add(self.tab_evaluate, text="4. 模型评估")
        self.init_evaluate_tab()

        # 5. 预测标签页
        self.tab_predict = ttk.Frame(self.tab_control)
        self.tab_control.add(self.tab_predict, text="5. 生产预测")
        self.init_predict_tab()

        self.tab_control.pack(expand=1, fill="both")

    def init_import_tab(self):
        frame = ttk.Frame(self.tab_import)
        frame.pack(padx=20, pady=20, fill="both", expand=True)

        ttk.Button(
            frame, text="选择CSV数据文件", command=self.load_data
        ).pack(anchor="w", pady=(0, 10))

        ttk.Label(frame, text="数据预览：").pack(anchor="w")
        self.tree = ttk.Treeview(frame, height=10)
        self.tree.pack(side="left", fill="both", expand=True)

        scrollbar = ttk.Scrollbar(frame, orient="vertical", command=self.tree.yview)
        scrollbar.pack(side="right", fill="y")
        self.tree.configure(yscrollcommand=scrollbar.set)

    def load_data(self):
        file_path = filedialog.askopenfilename(
            filetypes=[("CSV文件", "*.csv")]
        )
        if not file_path:
            return

        try:
            self.raw_data = pd.read_csv(file_path)
            self.update_tree_view(self.raw_data)
            messagebox.showinfo("成功", f"数据加载完成，共 {len(self.raw_data)} 行，{len(self.raw_data.columns)} 列")
            self.tab_control.select(1)
        except Exception as e:
            messagebox.showerror("错误", f"数据加载失败：{str(e)}")

    def update_tree_view(self, df):
        self.tree.delete(*self.tree.get_children())
        self.tree["columns"] = list(df.columns)
        self.tree["show"] = "headings"
        for col in df.columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=100)
        for _, row in df.head(50).iterrows():
            self.tree.insert("", "end", values=list(row))

    def init_clean_tab(self):
        frame = ttk.Frame(self.tab_clean)
        frame.pack(padx=20, pady=20, fill="both", expand=True)

        ttk.Label(frame, text="缺失值处理方式：").pack(anchor="w", pady=(0, 5))
        self.missing_var = tk.StringVar(value="median")
        ttk.Radiobutton(
            frame, text="中位数填充（推荐）", variable=self.missing_var, value="median"
        ).pack(anchor="w")
        ttk.Radiobutton(
            frame, text="均值填充", variable=self.missing_var, value="mean"
        ).pack(anchor="w")

        ttk.Label(frame, text="异常值处理方式：").pack(anchor="w", pady=(10, 5))
        self.outlier_var = tk.StringVar(value="iqr")
        ttk.Radiobutton(
            frame, text="IQR法删除（推荐）", variable=self.outlier_var, value="iqr"
        ).pack(anchor="w")
        ttk.Radiobutton(
            frame, text="保留异常值", variable=self.outlier_var, value="keep"
        ).pack(anchor="w")

        ttk.Button(
            frame, text="执行数据清理", command=self.clean_data
        ).pack(anchor="w", pady=10)

        self.clean_result = tk.Text(frame, height=5, width=80)
        self.clean_result.pack(fill="x", pady=10)

        ttk.Label(frame, text="清理后的数据预览：").pack(anchor="w")
        self.clean_tree = ttk.Treeview(frame, height=5)
        self.clean_tree.pack(fill="both", expand=True)
        scrollbar = ttk.Scrollbar(frame, orient="vertical", command=self.clean_tree.yview)
        scrollbar.pack(side="right", fill="y")
        self.clean_tree.configure(yscrollcommand=scrollbar.set)

    def clean_data(self):
        if self.raw_data is None:
            messagebox.showwarning("警告", "请先导入数据")
            return

        try:
            df = self.raw_data.copy()
            original_shape = df.shape

            if self.missing_var.get() == "median":
                df = df.fillna(df.median(numeric_only=True))
            else:
                df = df.fillna(df.mean(numeric_only=True))

            if self.outlier_var.get() == "iqr":
                for col in df.columns:
                    if pd.api.types.is_numeric_dtype(df[col]):
                        q1 = df[col].quantile(0.25)
                        q3 = df[col].quantile(0.75)
                        iqr = q3 - q1
                        lower = q1 - 1.5 * iqr
                        upper = q3 + 1.5 * iqr
                        if col == "温度":
                            lower = max(lower, 20)
                            upper = min(upper, 30)
                        elif col == "湿度":
                            lower = max(lower, 80)
                            upper = min(upper, 98)
                        df = df[(df[col] >= lower) & (df[col] <= upper)]

            self.cleaned_data = df
            cleaned_shape = df.shape

            self.clean_result.delete(1.0, tk.END)
            self.clean_result.insert(tk.END, 
                f"清理前：{original_shape[0]}行，{original_shape[1]}列\n"
                f"清理后：{cleaned_shape[0]}行，{cleaned_shape[1]}列\n"
                f"删除异常值：{original_shape[0] - cleaned_shape[0]}行"
            )

            self.update_clean_tree_view(df)
            messagebox.showinfo("成功", "数据清理完成")
            self.tab_control.select(2)
        except Exception as e:
            messagebox.showerror("错误", f"清理失败：{str(e)}")

    def update_clean_tree_view(self, df):
        self.clean_tree.delete(*self.clean_tree.get_children())
        self.clean_tree["columns"] = list(df.columns)
        self.clean_tree["show"] = "headings"
        for col in df.columns:
            self.clean_tree.heading(col, text=col)
            self.clean_tree.column(col, width=80)
        for _, row in df.head(10).iterrows():
            self.clean_tree.insert("", "end", values=list(row))

    def init_train_tab(self):
        frame = ttk.Frame(self.tab_train)
        frame.pack(padx=20, pady=20, fill="both", expand=True)

        param_frame = ttk.LabelFrame(frame, text="训练参数")
        param_frame.pack(fill="x", pady=(0, 10))

        ttk.Label(param_frame, text="批次大小：").grid(row=0, column=0, padx=10, pady=5)
        self.batch_var = tk.StringVar(value="16")
        ttk.Entry(param_frame, textvariable=self.batch_var, width=10).grid(row=0, column=1)

        ttk.Label(param_frame, text="最大迭代次数：").grid(row=0, column=2, padx=10, pady=5)
        self.epoch_var = tk.StringVar(value="100")
        ttk.Entry(param_frame, textvariable=self.epoch_var, width=10).grid(row=0, column=3)

        ttk.Button(
            frame, text="开始模型训练", command=self.train_model
        ).pack(anchor="w", pady=10)

        self.train_log = tk.Text(frame, height=5, width=80)
        self.train_log.pack(fill="x", pady=10)

        self.fig_loss, self.ax_loss = plt.subplots(figsize=(8, 4))
        self.canvas_loss = FigureCanvasTkAgg(self.fig_loss, master=frame)
        self.canvas_loss.get_tk_widget().pack(fill="both", expand=True)

    def train_model(self):
        if self.cleaned_data is None:
            messagebox.showwarning("警告", "请先完成数据清理")
            return

        try:
            X = self.cleaned_data.iloc[:, :-2].copy()
            X["温湿度交互"] = X["温度"] * X["湿度"]
            X["CO2与通风交互"] = X["CO2浓度"] / (X["通风量"] + 1)
            X = X.values
            y = self.cleaned_data.iloc[:, -2:].values

            self.X_train, X_temp, self.y_train, y_temp = train_test_split(
                X, y, test_size=0.3, random_state=42
            )
            self.X_val, self.X_test, self.y_val, self.y_test = train_test_split(
                X_temp, y_temp, test_size=0.5, random_state=42
            )

            self.scaler_X = MinMaxScaler()
            self.X_train = self.scaler_X.fit_transform(self.X_train)
            self.X_val = self.scaler_X.transform(self.X_val)
            self.X_test = self.scaler_X.transform(self.X_test)

            self.scaler_y = MinMaxScaler()
            self.y_train = self.scaler_y.fit_transform(self.y_train)
            self.y_val = self.scaler_y.transform(self.y_val)
            self.y_test = self.scaler_y.transform(self.y_test)

            input_dim = self.X_train.shape[1]
            self.model = tf.keras.Sequential([
                tf.keras.layers.Dense(32, activation='relu', input_dim=input_dim, kernel_regularizer=tf.keras.regularizers.L2(0.001)),
                tf.keras.layers.Dropout(0.2),
                tf.keras.layers.Dense(16, activation='relu', kernel_regularizer=tf.keras.regularizers.L2(0.001)),
                tf.keras.layers.Dropout(0.2),
                tf.keras.layers.Dense(2, activation='linear')
            ])

            self.model.compile(
                optimizer=tf.keras.optimizers.Adam(learning_rate=0.001),
                loss='mse',
                metrics=[tf.keras.metrics.RootMeanSquaredError(name='rmse'),
                         tf.keras.metrics.R2Score(name='r2')]
            )

            early_stopping = tf.keras.callbacks.EarlyStopping(
                monitor='val_loss', patience=8, restore_best_weights=True
            )
            lr_scheduler = tf.keras.callbacks.ReduceLROnPlateau(
                monitor='val_loss', factor=0.5, patience=3, min_lr=1e-6
            )

            self.train_log.delete(1.0, tk.END)
            self.train_log.insert(tk.END, "开始训练模型...\n")
            self.root.update()

            history = self.model.fit(
                self.X_train, self.y_train,
                epochs=int(self.epoch_var.get()),
                batch_size=int(self.batch_var.get()),
                validation_data=(self.X_val, self.y_val),
                callbacks=[early_stopping, lr_scheduler],
                verbose=0
            )

            os.makedirs("../models", exist_ok=True)
            self.model.save("../models/production_model.keras")
            joblib.dump(self.scaler_X, "../models/scaler_X.pkl")
            joblib.dump(self.scaler_y, "../models/scaler_y.pkl")

            self.train_log.insert(tk.END, 
                f"训练完成！迭代次数：{len(history.history['loss'])}\n"
                f"训练损失：{history.history['loss'][-1]:.4f}\n"
                f"验证损失：{history.history['val_loss'][-1]:.4f}\n"
                f"验证R²：{history.history['val_r2'][-1]:.4f}"
            )

            self.ax_loss.clear()
            self.ax_loss.plot(history.history['loss'], label='训练损失')
            self.ax_loss.plot(history.history['val_loss'], label='验证损失')
            self.ax_loss.set_xlabel('迭代次数')
            self.ax_loss.set_ylabel('MSE')
            self.ax_loss.set_title('训练损失曲线')
            self.ax_loss.legend()
            self.canvas_loss.draw()

            messagebox.showinfo("成功", "模型训练完成，已保存至models目录")
            self.tab_control.select(3)
        except Exception as e:
            messagebox.showerror("错误", f"训练失败：{str(e)}")

    def init_evaluate_tab(self):
        frame = ttk.Frame(self.tab_evaluate)
        frame.pack(padx=20, pady=20, fill="both", expand=True)

        ttk.Button(
            frame, text="执行模型评估", command=self.evaluate_model
        ).pack(anchor="w", pady=10)

        self.eval_metrics = tk.Text(frame, height=5, width=80)
        self.eval_metrics.pack(fill="x", pady=10)

        vis_frame = ttk.Frame(frame)
        vis_frame.pack(fill="both", expand=True)

        self.fig_pred, self.ax_pred = plt.subplots(figsize=(4, 4))
        self.canvas_pred = FigureCanvasTkAgg(self.fig_pred, master=vis_frame)
        self.canvas_pred.get_tk_widget().grid(row=0, column=0, padx=5, pady=5, sticky="nsew")

        self.fig_shap, self.ax_shap = plt.subplots(figsize=(4, 4))
        self.canvas_shap = FigureCanvasTkAgg(self.fig_shap, master=vis_frame)
        self.canvas_shap.get_tk_widget().grid(row=0, column=1, padx=5, pady=5, sticky="nsew")

        vis_frame.grid_columnconfigure(0, weight=1)
        vis_frame.grid_columnconfigure(1, weight=1)
        vis_frame.grid_rowconfigure(0, weight=1)

    def evaluate_model(self):
        if self.model is None:
            try:
                self.model = tf.keras.models.load_model("../models/production_model.keras")
                self.scaler_X = joblib.load("../models/scaler_X.pkl")
                self.scaler_y = joblib.load("../models/scaler_y.pkl")
                if self.X_test is None:
                    messagebox.showwarning("警告", "请先完成模型训练")
                    return
            except:
                messagebox.showwarning("警告", "请先完成模型训练")
                return

        try:
            loss, rmse, r2 = self.model.evaluate(self.X_test, self.y_test, verbose=0)
            self.eval_metrics.delete(1.0, tk.END)
            self.eval_metrics.insert(tk.END,
                f"测试集评估指标：\n"
                f"均方误差（MSE）：{loss:.4f}\n"
                f"根均方误差（RMSE）：{rmse:.4f}\n"
                f"决定系数（R²）：{r2:.4f}"
            )

            y_pred_scaled = self.model.predict(self.X_test, verbose=0)
            y_pred = self.scaler_y.inverse_transform(y_pred_scaled)
            y_test_original = self.scaler_y.inverse_transform(self.y_test)

            self.ax_pred.clear()
            self.ax_pred.scatter(y_test_original[:, 0], y_pred[:, 0], alpha=0.6)
            self.ax_pred.plot(
                [y_test_original[:,0].min(), y_test_original[:,0].max()],
                [y_test_original[:,0].min(), y_test_original[:,0].max()],
                'r--'
            )
            self.ax_pred.set_xlabel('真实鲜重产量（kg/㎡）')
            self.ax_pred.set_ylabel('预测鲜重产量（kg/㎡）')
            self.ax_pred.set_title('产量预测 vs 真实值')
            self.canvas_pred.draw()

            explainer = shap.KernelExplainer(self.model.predict, self.X_test[:50])
            shap_values = explainer.shap_values(self.X_test[:50])
            feature_names = ["温度", "湿度", "CO2浓度", "光照强度", "培养时间", "通风量", "温湿度交互", "CO2与通风交互"]
            
            self.fig_shap.clear()
            shap.summary_plot(shap_values, self.X_test[:50], feature_names=feature_names, 
                             plot_type="bar", show=False)
            plt.title('特征重要性')
            self.canvas_shap.draw()

            messagebox.showinfo("成功", "模型评估完成")
            self.tab_control.select(4)
        except Exception as e:
            messagebox.showerror("错误", f"评估失败：{str(e)}")

    def init_predict_tab(self):
        frame = ttk.Frame(self.tab_predict)
        frame.pack(padx=20, pady=20, fill="both", expand=True)

        input_frame = ttk.LabelFrame(frame, text="输入环境参数")
        input_frame.pack(fill="x", pady=(0, 10))

        params = [
            ("温度（℃）：", "temp", 25.0),
            ("湿度（%）：", "humidity", 90.0),
            ("CO2浓度（ppm）：", "co2", 1000),
            ("光照强度（lux）：", "light", 60),
            ("培养时间（天）：", "time", 8),
            ("通风量（m³/h）：", "vent", 120)
        ]

        self.param_vars = {}
        for i, (label, key, default) in enumerate(params):
            row, col = i // 2, i % 2 * 2
            ttk.Label(input_frame, text=label).grid(row=row, column=col, padx=10, pady=5, sticky="e")
            var = tk.DoubleVar(value=default)
            self.param_vars[key] = var
            ttk.Entry(input_frame, textvariable=var, width=15).grid(row=row, column=col+1, pady=5)

        ttk.Button(
            frame, text="预测产量和转化率", command=self.predict
        ).pack(anchor="w", pady=10)

        result_frame = ttk.LabelFrame(frame, text="预测结果")
        result_frame.pack(fill="x", pady=10)

        self.result_text = tk.Text(result_frame, height=3, font=("SimHei", 12))
        self.result_text.pack(fill="x", padx=10, pady=10)

        self.fig_result, self.ax_result = plt.subplots(figsize=(8, 3))
        self.canvas_result = FigureCanvasTkAgg(self.fig_result, master=frame)
        self.canvas_result.get_tk_widget().pack(fill="both", expand=True)

    def predict(self):
        if self.model is None:
            try:
                self.model = tf.keras.models.load_model("../models/production_model.keras")
                self.scaler_X = joblib.load("../models/scaler_X.pkl")
                self.scaler_y = joblib.load("../models/scaler_y.pkl")
            except:
                messagebox.showwarning("警告", "请先完成模型训练")
                return

        try:
            temp = self.param_vars["temp"].get()
            humidity = self.param_vars["humidity"].get()
            co2 = self.param_vars["co2"].get()
            light = self.param_vars["light"].get()
            time = self.param_vars["time"].get()
            vent = self.param_vars["vent"].get()

            if not (20 <= temp <= 30):
                messagebox.showwarning("警告", "温度应在20-30℃之间")
                return
            if not (80 <= humidity <= 98):
                messagebox.showwarning("警告", "湿度应在80-98%之间")
                return

            new_data = np.array([[temp, humidity, co2, light, time, vent]])
            new_data = np.hstack([
                new_data,
                [[temp * humidity]],
                [[co2 / (vent + 1)]]
            ])

            new_data_scaled = self.scaler_X.transform(new_data)
            pred_scaled = self.model.predict(new_data_scaled, verbose=0)
            pred = self.scaler_y.inverse_transform(pred_scaled)[0]

            self.result_text.delete(1.0, tk.END)
            self.result_text.insert(tk.END,
                f"预测鲜重产量：{pred[0]:.2f} kg/㎡\n"
                f"预测生物转化率：{pred[1]:.2f} %"
            )

            self.ax_result.clear()
            bars = self.ax_result.bar(["鲜重产量（kg/㎡）", "生物转化率（%）"], pred, color=['#4CAF50', '#2196F3'])
            self.ax_result.set_ylim(0, max(pred) * 1.2)
            for bar in bars:
                height = bar.get_height()
                self.ax_result.text(bar.get_x() + bar.get_width()/2., height + 0.05,
                                    f'{height:.2f}', ha='center', va='bottom')
            self.ax_result.set_title('茶树菇生产预测结果')
            self.canvas_result.draw()
        except Exception as e:
            messagebox.showerror("错误", f"预测失败：{str(e)}")


if __name__ == "__main__":
    os.makedirs("../data/raw", exist_ok=True)
    os.makedirs("../models", exist_ok=True)
    os.makedirs("../results", exist_ok=True)
    
    root = tk.Tk()
    app = MushroomModelGUI(root)
    root.mainloop()